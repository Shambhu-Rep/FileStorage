package org.hi;

import org.testng.annotations.Test;

public class Sample {
	
	@Test
	public void test11() {
		System.out.println("test11");

	}
	@Test
	public void test22() {
		System.out.println("test22");

	}
	@Test
	public void test33() {
		System.out.println("test33");

	}

	@Test
	public void test() {
		System.out.println("test");

	}
	@Test
	public void test1() {
		System.out.println("tes1t");

	}
	@Test
	public void test14() {
		System.out.println("test14");

	}
	}

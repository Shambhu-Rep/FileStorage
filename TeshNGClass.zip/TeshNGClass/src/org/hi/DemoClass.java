package org.hi;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DemoClass {
	@Test
	public void test10() {
		System.out.println("test10");
	}
	@Test()
	public void test11() {
		System.out.println("test11");
	}
	@Test()
	public void test12() {
		System.out.println("test12");

	}
	@Test
	public void test13() {
		System.out.println("test13");

	}
	@Test
	public void test14() {
		System.out.println("test14");

	}
	@Test
	public void test15() {
		System.out.println("test15");

	}
	@Test
	public void test16() {
		System.out.println("test16");

	}
}

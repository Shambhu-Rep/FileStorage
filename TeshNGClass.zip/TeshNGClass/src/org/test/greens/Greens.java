package org.test.greens;

import org.testng.annotations.Test;

public class Greens {
	@Test
	public void test22() {
		System.out.println("test22");

	}
	@Test
	public void test33() {
		System.out.println("test33");

	}
	@Test
	public void test44() {
		System.out.println("test44");

	}
	@Test
	public void test55() {
		System.out.println("test55");

	}
	

}

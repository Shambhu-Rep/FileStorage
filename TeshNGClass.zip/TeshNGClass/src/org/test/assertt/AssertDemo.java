package org.test.assertt;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertDemo {
	@Test
	public void test1() {
		Assert.assertTrue(true, "Verify Username");
		Assert.assertTrue(true, "Verify Password");
		Assert.assertTrue(true, "Verify button");
		Assert.assertTrue(true, "Verify info");

	}
	@Test
	public void test2() {
		Assert.assertTrue(true, "Verify details");
	}
	@Test
	public void test21() {
		Assert.assertTrue(true, "Verify details");
	}
	@Test
	public void test22() {
		Assert.assertTrue(true, "Verify details");
	}
	@Test
	public void test23() {
		Assert.assertTrue(true, "Verify details");
	}
	@Test
	public void test24() {
		Assert.assertTrue(true, "Verify details");
	}
}
